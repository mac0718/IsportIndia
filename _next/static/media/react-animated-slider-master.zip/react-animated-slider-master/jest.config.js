module.exports = {
	verbose: true,
};
